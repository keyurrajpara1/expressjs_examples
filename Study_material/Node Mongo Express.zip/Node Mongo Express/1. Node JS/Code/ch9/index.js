// OS Module
import os from 'os';
console.log(os.platform());
console.log(os.arch());
console.log(os.cpus());
console.log(os.hostname());
console.log(os.homedir());
console.log(os.networkInterfaces());
console.log(os.freemem());
console.log(os.totalmem());