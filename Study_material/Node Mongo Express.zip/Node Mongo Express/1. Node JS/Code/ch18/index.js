// Import & Export Module - ES6
import name from './student.js';
console.log(name);

// import { nm, marks } from './student.js';
// console.log(nm);
// marks(10, 20);