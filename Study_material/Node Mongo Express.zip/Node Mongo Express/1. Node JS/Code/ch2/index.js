// Module Wrapper
// (function (exports, require, module, __filename, __dirname) {
//  // Module code actually lives in here
// });

console.log("Hello GeekyShows");
console.log(__dirname);
console.log(__filename);
// console.log(module);