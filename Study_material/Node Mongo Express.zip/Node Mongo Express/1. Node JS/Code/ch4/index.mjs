// const path = require('path');
import path from 'path';

console.log(path.basename('c:\\nodejs\\ch4\\index.js'));
// console.log(__filename);
// console.log(__dirname);