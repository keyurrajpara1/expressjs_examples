const homeController = (req, res) => {
 res.render('index')
}

export { homeController }