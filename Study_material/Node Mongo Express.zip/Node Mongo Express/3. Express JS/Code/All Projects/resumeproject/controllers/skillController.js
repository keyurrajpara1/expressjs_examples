const skillController = (req, res) => {
 res.render('skill', { 'title': 'Skill' })
}

export { skillController }